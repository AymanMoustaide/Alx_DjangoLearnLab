from bookshelf.models import Book

new_book.title = "Nineteen Eighty-Four”
new_book.save()